<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentBookingTime extends Model
{
    protected $fillable = ['time','status'];
}
